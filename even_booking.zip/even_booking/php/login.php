<?php
session_start();
include '../php/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($query);

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user'] = $user['name'];
            $_SESSION['email'] = $user['email'];
            header('Location: ../pages/dashboard.php');
        } else {
            echo "<script>alert('Invalid password!');</script>";
        }
    } else {
        echo "<script>alert('User not found!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Movie Booking</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            height: 100vh;
            background-color: #000;
            overflow: hidden;
        }

        /* Video Background */
        .video-container {
            position: fixed;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: -1;
        }

        video {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* Login Container */
        .login-container {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 350px;
            background: rgba(0, 0, 0, 0.8);
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(255, 0, 0, 0.7);
            text-align: center;
        }

        .login-container h2 {
            color: #ff4d4d;
            margin-bottom: 20px;
            font-size: 26px;
        }

        /* Input Fields */
        .login-container input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ff4d4d;
            border-radius: 6px;
            background-color: #222;
            color: #fff;
        }

        /* Button Style */
        .login-container button {
            width: 100%;
            padding: 12px;
            background: #ff4d4d;
            border: none;
            border-radius: 6px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .login-container button:hover {
            background: #e33e3e;
        }

        /* Links */
        .login-container a {
            display: inline-block;
            margin-top: 12px;
            color: #ff4d4d;
            text-decoration: none;
        }

        .login-container a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <!-- Video Background -->
    <div class="video-container">
        <video autoplay muted loop>
            <source src="../images/vd1.mp4" type="video/mp4" />
            Your browser does not support the video tag.
        </video>
    </div>

    <!-- Login Container -->
    <div class="login-container">
        <h2>🎥 Movie Ticket Booking</h2>
        <form action="../php/login.php" method="POST">
            <input type="email" name="email" placeholder="📧 Email" required />
            <input type="password" name="password" placeholder="🔒 Password" required />
            <button type="submit">Login</button>
        </form>
        <a href="forgot.php">Forgot Password?</a> |
        <a href="register.php">Register</a>
    </div>
</body>

</html>
