<?php
include '../php/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $check_email = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($check_email);

    if ($result->num_rows == 0) {
        $query = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";
        if ($conn->query($query)) {
            echo "<script>alert('Registration Successful!'); window.location.href='../index.php';</script>";
        } else {
            echo "<script>alert('Error: " . $conn->error . "');</script>";
        }
    } else {
        echo "<script>alert('Email already exists!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | Movie Booking</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            height: 100vh;
            background-color: #000;
            overflow: hidden;
        }

        /* Video Background */
        .video-container {
            position: fixed;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: -1;
        }

        video {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* Register Container */
        .register-container {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 350px;
            background: rgba(0, 0, 0, 0.8);
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(255, 0, 0, 0.7);
            text-align: center;
        }

        .register-container h2 {
            color: #ff4d4d;
            margin-bottom: 20px;
            font-size: 26px;
        }

        /* Input Fields */
        .register-container input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ff4d4d;
            border-radius: 6px;
            background-color: #222;
            color: #fff;
        }

        /* Button Style */
        .register-container button {
            width: 100%;
            padding: 12px;
            background: #ff4d4d;
            border: none;
            border-radius: 6px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .register-container button:hover {
            background: #e33e3e;
        }

        /* Links */
        .register-container a {
            display: inline-block;
            margin-top: 12px;
            color: #ff4d4d;
            text-decoration: none;
        }

        .register-container a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <!-- Video Background -->
    <div class="video-container">
        <video autoplay muted loop>
            <source src="../images/vd.mp4" type="video/mp4" />
            Your browser does not support the video tag.
        </video>
    </div>

    <!-- Register Container -->
    <div class="register-container">
        <h2>🎟️ Create Your Account</h2>
        <form action="../php/register.php" method="POST">
            <input type="text" name="name" placeholder="👤 Full Name" required />
            <input type="email" name="email" placeholder="📧 Email" required />
            <input type="password" name="password" placeholder="🔒 Password" required />
            <button type="submit">Register</button>
        </form>
        <a href="login.php">Already have an account? Login</a>
    </div>
</body>

</html>
