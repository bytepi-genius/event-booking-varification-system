<?php
include '../php/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $new_password = password_hash('123456', PASSWORD_BCRYPT);

    $check_email = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($check_email);

    if ($result->num_rows == 1) {
        $query = "UPDATE users SET password='$new_password' WHERE email='$email'";
        if ($conn->query($query)) {
            echo "<script>alert('✅ Password reset successful! New password: 123456'); window.location.href='login.php';</script>";
        } else {
            echo "<script>alert('⚠️ Error updating password.');</script>";
        }
    } else {
        echo "<script>alert('❌ Email not found!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password | Movie Booking</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            height: 100vh;
            background-color: #000;
            overflow: hidden;
        }

        /* Video Background */
        .video-container {
            position: fixed;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: -1;
        }

        video {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* Forgot Password Container */
        .forgot-container {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 350px;
            background: rgba(0, 0, 0, 0.8);
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(255, 0, 0, 0.7);
            text-align: center;
        }

        .forgot-container h2 {
            color: #ff4d4d;
            margin-bottom: 20px;
            font-size: 26px;
        }

        /* Input Fields */
        .forgot-container input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ff4d4d;
            border-radius: 6px;
            background-color: #222;
            color: #fff;
        }

        /* Button Style */
        .forgot-container button {
            width: 100%;
            padding: 12px;
            background: #ff4d4d;
            border: none;
            border-radius: 6px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .forgot-container button:hover {
            background: #e33e3e;
        }

        /* Links */
        .forgot-container a {
            display: inline-block;
            margin-top: 12px;
            color: #ff4d4d;
            text-decoration: none;
        }

        .forgot-container a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <!-- Video Background -->
    <div class="video-container">
        <video autoplay muted loop>
            <source src="../images/vd3.mp4" type="video/mp4" />
            Your browser does not support the video tag.
        </video>
    </div>

    <!-- Forgot Password Container -->
    <div class="forgot-container">
        <h2>🔐 Reset Your Password</h2>
        <form action="../php/forgot.php" method="POST">
            <input type="email" name="email" placeholder="📧 Enter your registered email" required />
            <button type="submit">Reset Password</button>
        </form>
        <a href="login.php">⬅️ Back to Login</a>
    </div>
</body>

</html>
