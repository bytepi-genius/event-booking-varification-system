<?php
$host = 'localhost';
$user = 'root';
$password = 'alisaif11016@gmail.com@Saif2004';
$db_name = 'event_booking';
$port = 3307;

// Create Connection
$conn = new mysqli($host, $user, $password, $db_name,$port);

// Check Connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
