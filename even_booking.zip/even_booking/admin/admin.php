<?php
session_start();
include '../php/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // File upload handling
    $target_dir = __DIR__ . "/../images/";

    // Check if exactly 3 files are uploaded
    if (isset($_FILES['banners']) && count($_FILES['banners']['name']) == 3) {
        $bannerFiles = [];

        for ($i = 0; $i < 3; $i++) {
            // Check if file was uploaded without errors
            if ($_FILES['banners']['error'][$i] == 0) {
                $bannerName = basename($_FILES['banners']['name'][$i]);
                $uploadPath = $target_dir . $bannerName;

                // Move uploaded file to target directory
                if (move_uploaded_file($_FILES['banners']['tmp_name'][$i], $uploadPath)) {
                    $bannerFiles[] = $bannerName; // Store the file names in an array
                } else {
                    echo "<script>alert('Error uploading image: $bannerName');</script>";
                    exit();
                }
            } else {
                echo "<script>alert('Error with file upload.');</script>";
                exit();
            }
        }

        // Check if all 3 banners are uploaded successfully
        if (count($bannerFiles) == 3) {
            // Assign file names correctly
            $banner1 = $bannerFiles[0];
            $banner2 = $bannerFiles[1];
            $banner3 = $bannerFiles[2];

            // Sanitize inputs before using them in the query
            $name = mysqli_real_escape_string($conn, $_POST['name']);
            $heading = mysqli_real_escape_string($conn, $_POST['heading']);
            $description = mysqli_real_escape_string($conn, $_POST['description']);
            $price = mysqli_real_escape_string($conn, $_POST['price']);
            $event_date = mysqli_real_escape_string($conn, $_POST['event_date']);
            $event_time = mysqli_real_escape_string($conn, $_POST['event_time']);
            $location = mysqli_real_escape_string($conn, $_POST['location']);

            // Insert data into the database
            $query = "INSERT INTO admin_post (banner1, banner2, banner3, name, heading, description, price, event_date, event_time, location)
                      VALUES ('$banner1', '$banner2', '$banner3', '$name', '$heading', '$description', '$price', '$event_date', '$event_time', '$location')";

            if ($conn->query($query)) {
                echo "<script>alert('Event successfully added!');</script>";
            } else {
                echo "<script>alert('Error adding event: " . $conn->error . "');</script>";
            }
        } else {
            echo "<script>alert('Error: Not all images uploaded correctly.');</script>";
        }
    } else {
        echo "<script>alert('Please upload exactly 3 images.');</script>";
    }
}
?>



<!DOCTYPE html>
<html>

<head>
    <title>Admin - Add Event</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css" />
    <style>
        .container {
            width: 60%;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            background-color: #f9f9f9;
            border-radius: 10px;
        }

        label {
            font-weight: bold;
        }

        input,
        textarea,
        select {
            width: 100%;
            padding: 8px;
            margin: 8px 0;
        }

        button {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #218838;
        }
    </style>
    <script>
        function validateFiles() {
            var fileInput = document.getElementById('bannerUpload');
            var fileCount = fileInput.files.length;

            if (fileCount !== 3) {
                alert("Please select exactly 3 images.");
                fileInput.value = ''; // Clear the selected files
            }
        }
    </script>
</head>

<body>
    <div class="container">
        <h2>Add New Event</h2>
        <form action="admin.php" method="POST" enctype="multipart/form-data">
    <label>Upload 3 Banners:</label>
    <input type="file" name="banners[]" multiple required />
    
    <label>Event Name:</label>
    <input type="text" name="name" required />

    <label>Heading:</label>
    <input type="text" name="heading" required />

    <label>Description:</label>
    <textarea name="description" rows="4" required></textarea>

    <label>Price:</label>
    <input type="number" step="0.01" name="price" required />

    <label>Date:</label>
    <input type="date" name="event_date" required />

    <label>Time:</label>
    <input type="time" name="event_time" required />

    <label>Location:</label>
    <select name="location" required>
        <option value="Delhi">Delhi</option>
        <option value="Mumbai">Mumbai</option>
        <option value="Patna">Patna</option>
        <option value="Chennai">Chennai</option>
        <option value="Kolkata">Kolkata</option>
        <option value="Bangalore">Bangalore</option>
        <option value="Hyderabad">Hyderabad</option>
        <option value="Ahmedabad">Ahmedabad</option>
        <option value="Pune">Pune</option>
        <option value="Jaipur">Jaipur</option>
        <option value="Lucknow">Lucknow</option>
        <option value="Chandigarh">Chandigarh</option>
    </select>

    <button type="submit">Add Event</button>
</form>

    </div>
</body>

</html>