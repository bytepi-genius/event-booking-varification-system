<?php
session_start();
include 'db.php';

// Ensure we only return JSON
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

// Prevent any accidental output
ob_start();

try {
    // Validate request method
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Only POST requests allowed', 405);
    }

    // Check if unique_id is provided
    if (!isset($_POST['unique_id']) || empty($_POST['unique_id'])) {
        throw new Exception('Unique ID is required', 400);
    }

    $unique_id = $conn->real_escape_string($_POST['unique_id']);

    // Get the most recent ticket
    $query = "SELECT * FROM payments_details WHERE unique_id = '$unique_id' ORDER BY created_at DESC LIMIT 1";
    $result = $conn->query($query);

    if (!$result) {
        throw new Exception('Database error: ' . $conn->error, 500);
    }

    if ($result->num_rows > 0) {
        $ticket = $result->fetch_assoc();
        
        $response = [
            'success' => true,
            'data' => [
                'id' => $ticket['id'],
                'payment_id' => $ticket['payment_id'],
                'price' => number_format($ticket['price'], 2),
                'unique_id' => $ticket['unique_id'],
                'created_at' => date('d M Y, h:i A', strtotime($ticket['created_at']))
            ]
        ];
        
        http_response_code(200);
        echo json_encode($response);
    } else {
        throw new Exception('Ticket not found', 404);
    }
} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} finally {
    // Clean any output buffers
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    $conn->close();
}
?>