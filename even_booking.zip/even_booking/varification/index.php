<?php
session_start();
include '../php/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['unique_id'])) {
    $unique_id = $_POST['unique_id'];

    // Fetch payment details from the database using unique_id
    $stmt = $conn->prepare("SELECT payment_id, price FROM payments_details WHERE unique_id = ? ORDER BY created_at DESC LIMIT 1"); // Get the latest entry
    $stmt->bind_param("s", $unique_id);
    $stmt->execute();
    $stmt->bind_result($payment_id, $price);
    $stmt->fetch();
    $stmt->close();

    if ($payment_id) {
        // ✅ Verified - Match Found
        echo "verified";
    } else {
        // ❌ Unverified - No Match Found
        echo "unverified";
    }

    $conn->close();
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Ticket Verification</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin-top: 50px;
        }

        .form-container {
            background-color: #0d2538;
            padding: 20px;
            border-radius: 10px;
            width: 400px;
            margin: auto;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            color: white;
        }

        input[type="text"] {
            padding: 12px;
            width: 100%;
            margin-top: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        button {
            padding: 12px 20px;
            margin-top: 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        .success-message {
            color: green;
            font-weight: bold;
            margin-top: 20px;
            display: none;
        }

        .error-message {
            color: red;
            font-weight: bold;
            margin-top: 20px;
            display: none;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>🎟️ Ticket Verification</h2>
    <form id="verification-form" method="POST">
        <input type="text" name="unique_id" placeholder="Enter Unique Batch ID" required>
        <button type="submit">Verify Ticket</button>
    </form>

    <div class="success-message" id="success-message">
        ✅ Ticket Verified Successfully!
    </div>

    <div class="error-message" id="error-message">
        ❌ Ticket Not Found or Unverified!
    </div>
</div>

<script>
    document.getElementById("verification-form").addEventListener("submit", function(e) {
        e.preventDefault();

        const uniqueId = document.getElementsByName("unique_id")[0].value;
        const successMessage = document.getElementById("success-message");
        const errorMessage = document.getElementById("error-message");

        fetch(window.location.href, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `unique_id=${encodeURIComponent(uniqueId)}`
        })
        .then(response => response.text())
        .then(data => {
            if (data === "verified") {
                successMessage.style.display = "block";
                errorMessage.style.display = "none";
            } else {
                successMessage.style.display = "none";
                errorMessage.style.display = "block";
            }
        });
    });




    document.getElementById("verification-form").addEventListener("submit", function(e) {
    e.preventDefault();

    const uniqueId = document.getElementsByName("unique_id")[0].value;
    const successMessage = document.getElementById("success-message");
    const errorMessage = document.getElementById("error-message");

    // Hide previous messages before new verification
    successMessage.style.display = "none";
    errorMessage.style.display = "none";

    fetch(window.location.href, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `unique_id=${encodeURIComponent(uniqueId)}`
    })
    .then(response => response.text())
    .then(data => {
        if (data === "verified") {
            successMessage.style.display = "block";
            errorMessage.style.display = "none";
        } else {
            successMessage.style.display = "none";
            errorMessage.style.display = "block";
        }

        // Hide messages after 1 second (1000ms)
        setTimeout(function() {
            successMessage.style.display = "none";
            errorMessage.style.display = "none";
        }, 500);
    });
});



setTimeout(function() {
    successMessage.style.display = "none";
    errorMessage.style.display = "none";
}, 500);

</script>

</body>
</html>
