-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: event_booking
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_post`
--

DROP TABLE IF EXISTS `admin_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_post` (
  `id` int NOT NULL AUTO_INCREMENT,
  `banner1` varchar(255) NOT NULL,
  `banner2` varchar(255) NOT NULL,
  `banner3` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `heading` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `event_date` date NOT NULL,
  `event_time` time NOT NULL,
  `location` enum('Delhi','Mumbai','Patna','Chennai','Kolkata','Bangalore','Hyderabad','Ahmedabad','Pune','Jaipur','Lucknow','Chandigarh') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_post`
--

LOCK TABLES `admin_post` WRITE;
/*!40000 ALTER TABLE `admin_post` DISABLE KEYS */;
INSERT INTO `admin_post` VALUES (2,'Red And Black Horror Movie Poster (2).png','Red And Black Horror Movie Poster (1).png','Red And Black Horror Movie Poster.png','Buster Movies Show','Buster Movies Show','Upcoming Blockbuster Movies\r\nThe world of cinema is buzzing with excitement as several highly anticipated movies are set to release this year. From action-packed thrillers and heartwarming dramas to mind-bending sci-fi adventures, there’s something for every movie lover. Big-budget films featuring A-list stars, captivating storylines, and stunning visual effects promise to keep audiences glued to their seats. Streaming platforms and theaters alike are gearing up for these blockbuster releases, ensuring that fans worldwide can enjoy an unforgettable cinematic experience. Whether you\'re into superheroes, romantic comedies, or fantasy epics, this year’s movie lineup has plenty to offer for everyone! ??\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n',500.00,'2025-03-31','18:00:00','Kolkata'),(3,'Red And Black Horror Movie Poster (2).png','Red And Black Horror Movie Poster (1).png','Red And Black Horror Movie Poster.png','Buster Movies Show','Buster Movies Show','Upcoming Blockbuster Movies\r\nThe world of cinema is buzzing with excitement as several highly anticipated movies are set to release this year. From action-packed thrillers and heartwarming dramas to mind-bending sci-fi adventures, there’s something for every movie lover. Big-budget films featuring A-list stars, captivating storylines, and stunning visual effects promise to keep audiences glued to their seats. Streaming platforms and theaters alike are gearing up for these blockbuster releases, ensuring that fans worldwide can enjoy an unforgettable cinematic experience. Whether you\'re into superheroes, romantic comedies, or fantasy epics, this year’s movie lineup has plenty to offer for everyone! ??\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n',500.00,'2025-03-31','18:00:00','Kolkata'),(4,'download (1).jpeg','Black White Bold Simple Initials Name Logo.png','man.png','Universe','Best for Universe','The Universe: A Vast, Mysterious Expanse ?✨\r\n\r\nThe universe is an infinite expanse of wonder, filled with countless galaxies, stars, and planets that stretch far beyond human comprehension. Estimated to be around 13.8 billion years old, the universe began with the Big Bang, an explosion that gave birth to space, time, and matter. Since then, it has been expanding continuously, with billions of galaxies drifting apart, each containing millions of stars and planetary systems. Amidst this cosmic symphony, black holes, nebulae, and dark matter weave a tapestry of mysteries waiting to be unraveled. Despite our advancements in astronomy and technology, we have barely scratched the surface of understanding this vast cosmos. As we gaze at the twinkling stars or explore distant planets, we are reminded that the universe holds endless secrets, igniting curiosity and inspiring the eternal quest for knowledge. ??\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n',1500.00,'2025-03-06','06:53:00','Pune'),(5,'dna3.png','dna2.png','dna1.jpg','DNA','DNA DEEP','DNA, or deoxyribonucleic acid, is the molecule that carries the genetic instructions necessary for the growth, development, functioning, and reproduction of all living organisms. It is composed of two strands that coil around each other to form a double helix, resembling a twisted ladder. Each strand is made up of a sequence of four chemical bases — adenine (A), thymine (T), cytosine (C), and guanine (G) — that pair up specifically (A with T and C with G), ensuring the accuracy of genetic information. DNA is found in the nucleus of cells and serves as a blueprint that determines inherited traits, influencing everything from physical characteristics to susceptibility to diseases. Through processes like replication, transcription, and translation, DNA plays a vital role in passing genetic information from one generation to the next.\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n',1000.00,'2025-03-29','08:08:00','Patna'),(6,'ai3.png','ai2.png','ai1.jpg','AI','Artificial Inteligence','Artificial Intelligence (AI) refers to the simulation of human intelligence processes by machines, particularly computer systems. These processes include learning (acquiring information and rules for using it), reasoning (using rules to reach approximate or definite conclusions), and self-correction. AI technologies are used in various applications, such as natural language processing, computer vision, speech recognition, and decision-making. There are two types of AI: narrow AI, which is designed to perform specific tasks (like virtual assistants and recommendation systems), and general AI, which aims to perform any intellectual task a human can do. AI is transforming industries by automating tasks, improving efficiency, and enabling innovations that were once thought impossible. However, it also raises ethical concerns regarding privacy, job displacement, and decision transparency.',5000.00,'2025-03-29','04:06:00','Kolkata'),(7,'r3.jpg','r2.jpg','r1.jpg','Love','Love','Love is a profound and complex emotion that encompasses feelings of affection, care, and attachment toward someone or something. It comes in many forms, including romantic love between partners, unconditional love between parents and children, and deep friendships. Love often inspires kindness, sacrifice, and understanding, making people feel valued and connected. It has the power to bring immense joy but can also lead to pain and heartbreak when expectations are unmet. Beyond human relationships, love can be felt for passions, hobbies, and even ideas. Ultimately, love is a driving force that shapes relationships, strengthens bonds, and gives meaning to life. ❤️',459.00,'2025-03-07','07:13:00','Patna'),(8,'cpp3.jpeg','cpp2.jpeg','cpp1.jpeg','bihar goverment','simple Photos','http://localhost:8080/even_booking/pages/details.php?id=6',200.00,'2025-03-19','22:40:00','Patna'),(9,'labrador-retriever-5753288_1920.jpg','dog-9413394_1920.jpg','56221562874.png','Dog','Dog Bluster','about dog',1200.00,'2025-03-31','19:00:00','Patna');
/*!40000 ALTER TABLE `admin_post` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-26  7:36:02
