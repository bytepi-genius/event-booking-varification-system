<?php
session_start();
include '../php/db.php';

// Check if ID is passed
if (isset($_GET['id'])) {
    $event_id = intval($_GET['id']);
// Set Default Profile Image if Not Set

    // Fetch event details
    $query = "SELECT * FROM admin_post WHERE id = $event_id";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $banner1 = $row['banner1'];
        $banner2 = $row['banner2'];
        $banner3 = $row['banner3'];
        $name = $row['name'];
        $heading = $row['heading'];
        $description = $row['description'];
        $price = $row['price'];
        $event_date = $row['event_date'];
        $event_time = $row['event_time'];
        $location = $row['location'];
    } else {
        echo "<p>Event not found!</p>";
        exit();
    }
} else {
    echo "<p>Invalid request!</p>";
    exit();
}


?>

<!DOCTYPE html>
<html>
<head>
    <title><?php echo $name; ?> - Event Details</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css" />
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>

    <style>
        .container {
            width: 70%;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 10px;
        }
        .image-gallery {
            display: flex;
            gap: 10px;
            justify-content: center;
        }
        .image-gallery img {
            width: 100px;
            height: 100px;
            cursor: pointer;
            border-radius: 5px;
        }
        #main-image {
            width: 100%;
            height: 400px;
            object-fit: cover;
            margin-bottom: 20px;
        }
        h2 {
            text-align: center;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            margin-top: 10px;
            cursor: pointer;
        }
        .btn-buy {
            background-color: #28a745;
            color: white;
        }
        .btn-wishlist {
            background-color: #ffc107;
            color: white;
        }
        .btn-like {
            background-color: #ff4d4d;
            color: white;
        }



        .top-right {
            position: absolute;
            top: 10px;
            right: 10px;
        }
        .user-profile {
            position: relative;
            display: inline-block;
            cursor: pointer;
        }
        .user-avatar {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    border: 2px solid #fff;
    object-fit: cover;
    cursor: pointer;
}

.dropdown-menu {
    position: absolute;
    top: 50px;
    right: 10px;
    background-color: #fff;
    box-shadow: 0px 4px 8px rgba(0,0,0,0.1);
    border-radius: 5px;
    overflow: hidden;
    display: none;
    z-index: 999;
}
.dropdown-menu a {
    display: block;
    padding: 10px 15px;
    color: #333;
    text-decoration: none;
}
.dropdown-menu a:hover {
    background-color: #f4f4f4;
}


body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }
        .container {
            width: 90%;
            margin: 50px auto;
        }
        .card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            overflow: hidden;
            width: 300px;
            display: inline-block;
            margin: 10px;
            cursor: pointer;
            transition: transform 0.2s ease-in-out;
        }
        .card:hover {
            transform: scale(1.05);
        }
        .card img {
            width: 100%;
            height: 180px;
            object-fit: cover;
        }
        .card-content {
            padding: 15px;
        }
        .card h3 {
            margin: 10px 0;
            font-size: 20px;
        }
        .card p {
            margin: 5px 0;
            color: #555;
        }
        .btn-container {
            margin-top: 10px;
            text-align: center;
        }
        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 5px;
        }
        .btn-buy {
            background-color: #28a745;
            color: white;
        }
        .btn-wishlist {
            background-color: #ffc107;
            color: white;
        }
        .btn-like {
            background-color: #ff4d4d;
            color: white;
        }


        

    </style>
    <script>
        function changeImage(src) {
            document.getElementById('main-image').src = src;
        }

        function toggleDropdown() {
        var dropdown = document.getElementById('dropdownMenu');
        dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
    }

    // Close dropdown if clicked outside
    window.onclick = function(event) {
        if (!event.target.matches('.user-avatar')) {
            var dropdown = document.getElementById('dropdownMenu');
            if (dropdown.style.display === 'block') {
                dropdown.style.display = 'none';
            }
        }
    }
    </script>
    
</head>
<body>

<div class="top-right">
    <div class="user-profile" onclick="toggleDropdown()">
        <?php
        // Set default avatar path
        $default_avatar = "../images/profiles/man.png";

        // Check if user avatar is set in session or database
        if (isset($_SESSION['avatar']) && !empty($_SESSION['avatar'])) {
            // No need to prepend "../images/profiles/" again
            $user_avatar = "../" . $_SESSION['avatar'];
        } else {
            $user_avatar = $default_avatar; // Show default avatar if none is uploaded
        }
        ?>
        <img src="<?php echo $user_avatar; ?>" alt="User Avatar" class="user-avatar" />
    </div>
</div>



<div class="container">
    <h2><?php echo $name; ?> - Event Details</h2>
    <img id="main-image" src="../images/<?php echo $banner1; ?>" alt="Main Banner">

    <div class="image-gallery">
        <img src="../images/<?php echo $banner1; ?>" onclick="changeImage('../images/<?php echo $banner1; ?>')" />
        <img src="../images/<?php echo $banner2; ?>" onclick="changeImage('../images/<?php echo $banner2; ?>')" />
        <img src="../images/<?php echo $banner3; ?>" onclick="changeImage('../images/<?php echo $banner3; ?>')" />
    </div>

    <h3><?php echo $heading; ?></h3>
    <p><strong>Description:</strong> <?php echo $description; ?></p>
    <p><strong>Price:</strong> ₹<?php echo $price; ?></p>
    <p><strong>Date:</strong> <?php echo $event_date; ?></p>
    <p><strong>Time:</strong> <?php echo $event_time; ?></p>
    <p><strong>Location:</strong> <?php echo $location; ?></p>

    <div class="container">
    <h2>Book Your Batch Now!</h2>
<button class="btn btn-buy" onclick="openCheckout()"> <strong>Book Now</strong></button>

</div>
</div>

<script>
    function openCheckout() {
        var price = <?php echo $price; ?>; // Dynamic Price from PHP

        var options = {
            "key": "rzp_test_CrbDsalYjYvbmm", // Razorpay Test Key
            "amount": (parseFloat(price) * 100).toFixed(0), // Convert price to paise
            "currency": "INR",
            "name": "Career Vision",
            "description": "Batch Payment",
            "handler": function (response) {
                // Generate a 10-character alphanumeric ID
                var uniqueId = generateUniqueId(10);

                // Redirect to unique_card.php with required details
                window.location.href =
                    "unique_card.php?payment_id=" +
                    response.razorpay_payment_id +
                    "&price=" +
                    price +
                    "&unique_id=" +
                    uniqueId;
            },
            "theme": {
                "color": "#3399cc"
            }
        };

        var rzp1 = new Razorpay(options);
        rzp1.open();
    }

    // Generate a random alphanumeric string of given length
    function generateUniqueId(length) {
        var chars = '0123456';
        var uniqueId = '';
        for (var i = 0; i < length/2; i++) {
            uniqueId += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return uniqueId;
    }
</script>


</body>
</html>
