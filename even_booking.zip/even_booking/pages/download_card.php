<?php
if (isset($_GET['payment_id']) && isset($_GET['price']) && isset($_GET['unique_id'])) {
    $payment_id = $_GET['payment_id'];
    $price = $_GET['price'];
    $unique_id = $_GET['unique_id'];

    $html = "
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; text-align: center; }
            .card {
                width: 600px;
                background-color: #0d2538;
                color: white;
                padding: 20px;
                border-radius: 10px;
                margin: auto;
            }
            .details { text-align: left; margin-top: 20px; }
            .qr-code { margin-top: 20px; }
        </style>
    </head>
    <body>
        <div class='card'>
            <h2>🎉 Payment Successful!</h2>
            <div class='details'>
                <p><strong>Payment ID:</strong> $payment_id</p>
                <p><strong>Price Paid:</strong> ₹$price</p>
                <p><strong>Unique Batch ID:</strong> $unique_id</p>
            </div>
            <div class='qr-code'>
                <img src='https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=" . urlencode('Payment ID: '.$payment_id.' | Batch ID: '.$unique_id) . "' alt='QR Code'>
            </div>
        </div>
    </body>
    </html>
    ";

    // Set headers to download as PDF
    header("Content-Type: application/pdf");
    header("Content-Disposition: attachment; filename=Batch_Ticket_$unique_id.pdf");

    require_once('dompdf/autoload.inc.php');
    use Dompdf\Dompdf;

    $dompdf = new Dompdf();
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();
    $dompdf->stream("Batch_Ticket_$unique_id.pdf", array("Attachment" => 1));
} else {
    echo "<h2>❌ Invalid request. No data found.</h2>";
}
?>
