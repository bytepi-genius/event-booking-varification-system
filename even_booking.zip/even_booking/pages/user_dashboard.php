<?php
session_start();
include '../php/db.php';

if (!isset($_SESSION['user'])) {
    header('Location: ../index.php');
    exit();
}

// Get User Details
$email = $_SESSION['email'];
$query = "SELECT * FROM users WHERE email='$email'";
$result = $conn->query($query);
$user = $result->fetch_assoc();

// Default profile icon if no avatar
$avatar_path = isset($user['avatar']) && $user['avatar'] != '' ? $user['avatar'] : "images/default-avatar.png";

// Handle Profile Update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);

    // Profile Image Upload Logic
    if ($_FILES['avatar']['name'] != '') {
        $target_dir = "../images/profiles/"; // Corrected directory
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true); // Create directory if not exists
        }

        // Create a unique name for the image
        $avatar_name = time() . "_" . basename($_FILES['avatar']['name']);
        $target_file = $target_dir . $avatar_name;

        // Move file to correct directory
        if (move_uploaded_file($_FILES['avatar']['tmp_name'], $target_file)) {
            $avatar_path = "images/profiles/" . $avatar_name; // Store relative path

            // Update query with avatar
            $query = "UPDATE users SET name='$name', avatar='$avatar_path' WHERE email='$email'";

            // Update session with new avatar
            $_SESSION['avatar'] = $avatar_path;
        } else {
            echo "<script>alert('Error uploading image. Please try again.');</script>";
            exit();
        }
    } else {
        // Update query without changing avatar
        $query = "UPDATE users SET name='$name' WHERE email='$email'";
    }

    // Execute query
    if ($conn->query($query)) {
        $_SESSION['user'] = $name;
        echo "<script>alert('Profile updated successfully!'); window.location.href='dashboard.php';</script>";
    } else {
        echo "<script>alert('Error updating profile: " . $conn->error . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Update Profile</title>
    <link rel="stylesheet" href="../css/style.css" />
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
        }
        .container {
            width: 40%;
            margin: 50px auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 8px;
        }
        h2 {
            text-align: center;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            font-weight: bold;
        }
        input[type="text"], input[type="file"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            width: 100%;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .profile-pic {
            text-align: center;
            margin-bottom: 20px;
        }
        .profile-pic img {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    border: 3px solid #ddd;
    object-fit: cover;
}

    </style>
</head>
<body>

<div class="container">
    <h2>Update Profile</h2>

   <!-- Profile Picture Section -->
<div class="profile-pic">
    <?php
    // Set default avatar path
    $default_avatar = "../images/profiles/man.png";

    // Check if user avatar is set in session or database
    if (isset($_SESSION['avatar']) && !empty($_SESSION['avatar'])) {
        // Use session avatar if available
        $avatar_path = "../" . $_SESSION['avatar'];
    } else {
        // Use default avatar if no avatar is uploaded
        $avatar_path = $default_avatar;
    }
    ?>
    <img src="<?php echo $avatar_path; ?>" alt="Profile Picture" />
</div>


    <!-- Profile Update Form -->
    <form method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label>Name:</label>
            <input type="text" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
        </div>

        <div class="form-group">
            <label>Change Profile Picture:</label>
            <input type="file" name="avatar" accept="image/*">
        </div>

        <button type="submit">Update Profile</button>
    </form>
</div>

</body>
</html>
