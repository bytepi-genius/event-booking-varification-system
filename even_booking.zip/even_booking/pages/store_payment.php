<?php
// Connect to database
$conn = new mysqli('localhost', 'root', '', 'event_booking');

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Check if POST data is received
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payment_id = $_POST['payment_id'];
    $order_id = $_POST['order_id'];
    $signature = $_POST['signature'];

    // Verify that payment_id, order_id, and signature are not empty
    if (!empty($payment_id) && !empty($order_id) && !empty($signature)) {
        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO payments_details (payment_id, order_id, signature) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $payment_id, $order_id, $signature);

        // Execute query
        if ($stmt->execute()) {
            echo "✅ Payment recorded successfully!";
        } else {
            echo "❌ Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "❌ Invalid data received!";
    }
} else {
    echo "❌ No data received!";
}

$conn->close();
?>
