<?php
include 'header.php';
include '../php/db.php';

if (!isset($_SESSION['user'])) {
    header('Location: ../index.php');
    exit();
}

// Set Default Profile Image if Not Set
$default_avatar = '../images/default_avatar.png'; // Path to default image
$user_avatar = isset($_SESSION['avatar']) ? $_SESSION['avatar'] : $default_avatar;



// Fetch event data from admin_post
// Fetch event data from admin_post
$query = "SELECT * FROM admin_post ORDER BY id DESC"; // Get all events
$result = $conn->query($query);


?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .top-right {
            position: absolute;
            top: 10px;
            right: 10px;
        }
        .user-profile {
            position: relative;
            display: inline-block;
            cursor: pointer;
        }
        .user-avatar {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    border: 2px solid #fff;
    object-fit: cover;
    cursor: pointer;
}

.dropdown-menu {
    position: absolute;
    top: 90px;
    right: 10px;
    background-color: #fff;
    box-shadow: 0px 4px 8px rgba(0,0,0,0.1);
    border-radius: 5px;
    overflow: hidden;
    display: none;
    z-index: 999;
}
.dropdown-menu a {
    display: block;
    padding: 10px 15px;
    color: #333;
    text-decoration: none;
}
.dropdown-menu a:hover {
    background-color: #f4f4f4;
}




        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }
        .container {
            width: 90%;
            margin: 50px auto;
        }
        .card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            overflow: hidden;
            width: 300px;
            display: inline-block;
            margin: 10px;
            cursor: pointer;
            transition: transform 0.2s ease-in-out;
        }
        .card:hover {
            transform: scale(1.05);
        }
        .card img {
            width: 100%;
            height: 180px;
            object-fit: cover;
        }
        .card-content {
            padding: 15px;
        }
        .card h3 {
            margin: 10px 0;
            font-size: 20px;
        }
        .card p {
            margin: 5px 0;
            color: #555;
        }
        .btn-container {
            margin-top: 10px;
            text-align: center;
        }
        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 5px;
        }
        .btn-buy {
            background-color: #28a745;
            color: white;
        }
        .btn-wishlist {
            background-color: #ffc107;
            color: white;
        }
        .btn-like {
            background-color: #ff4d4d;
            color: white;
        }


        
    </style>
   <script>
    function toggleDropdown() {
        var dropdown = document.getElementById('dropdownMenu');
        dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
    }

    // Close dropdown if clicked outside
    window.onclick = function(event) {
        if (!event.target.matches('.user-avatar')) {
            var dropdown = document.getElementById('dropdownMenu');
            if (dropdown.style.display === 'block') {
                dropdown.style.display = 'none';
            }
        }
    }
</script>

</head>
<body>


<div class="top-right">
    <div class="user-profile" onclick="toggleDropdown()">
        <?php
        // Set default avatar path
        $default_avatar = "../images/profiles/man.png";

        // Check if user avatar is set in session or database
        if (isset($_SESSION['avatar']) && !empty($_SESSION['avatar'])) {
            // No need to prepend "../images/profiles/" again
            $user_avatar = "../" . $_SESSION['avatar'];
        } else {
            $user_avatar = $default_avatar; // Show default avatar if none is uploaded
        }
        ?>
        <img src="<?php echo $user_avatar; ?>" alt="User Avatar" class="user-avatar" />
    </div>
</div>

    <!-- Dropdown Menu -->
    <div id="dropdownMenu" class="dropdown-menu">
        <a href="user_dashboard.php"><i class="fas fa-user"></i> Profile</a>
        <a href="../php/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</div>





    <div class="container">
    
    <h3>Available Events</h3>

    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $banner1 = $row['banner1'];
            $name = $row['name'];
            $event_date = $row['event_date'];
            $event_time = $row['event_time'];
            $location = $row['location'];
            $id = $row['id']; // Get event ID
    ?>
            <!-- Event Card -->
            <div class="card" onclick="window.location.href='details.php?id=<?php echo $id; ?>'">
                <img src="../images/<?php echo $banner1; ?>" alt="Event Banner">
                <div class="card-content">
                    <h3><?php echo $name; ?></h3>
                    <p><strong>Date:</strong> <?php echo $event_date; ?></p>
                    <p><strong>Time:</strong> <?php echo $event_time; ?></p>
                    <p><strong>Location:</strong> <?php echo $location; ?></p>
                </div>
               
            </div>
    <?php
        }
    } else {
        echo "<p>No events available.</p>";
    }
    ?>
</div>
    <!-- JavaScript to Change Main Image on Click -->
    <script>
        function changeImage(src) {
            document.getElementById('mainImage').src = src;
        }
    </script>
    
</body>
</html>
