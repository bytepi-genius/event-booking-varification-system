<?php
session_start();
include '../php/db.php';

// Function to generate a visually appealing movie ticket
function generateMovieTicket($payment_id, $price, $unique_id, $error = null) {
    // Sample movie details (in a real app, these would come from your database)
    $movieTitle = "Surprise";
    $showtime = "May 5, 2023 - 7:30 PM";
    $theater = "PVR Cinemas, Mumbai";
    $seats = "G5, G6, G7";
    $duration = "3h 1m";
    $barcode = "https://barcode.tec-it.com/barcode.ashx?data=" . urlencode($unique_id) . "&code=Code128&dpi=96";

    // Ticket styling
    $ticketStyle = "<style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap');
        
        body {
            background-color: #f5f7fa;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            font-family: 'Poppins', sans-serif;
        }
        
        .ticket-container {
            width: 380px;
            margin: 30px auto;
            background: white;
            font-family: 'Poppins', sans-serif;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
            border-radius: 12px;
            overflow: hidden;
            position: relative;
        }
        
        .ticket-header {
            background: linear-gradient(135deg, #6e48aa 0%, #9d50bb 100%);
            color: white;
            padding: 20px;
            text-align: center;
            position: relative;
        }
        
        .ticket-header h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 700;
            letter-spacing: 1px;
        }
        
        .ticket-header p {
            margin: 5px 0 0;
            font-size: 14px;
            opacity: 0.9;
        }
        
        .ticket-image {
            width: 100%;
            height: 180px;
            object-fit: cover;
            display: block;
        }
        
        .ticket-details {
            padding: 20px;
        }
        
        .detail-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 12px;
            border-bottom: 1px dashed #e0e0e0;
            padding-bottom: 12px;
        }
        
        .detail-row:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        
        .detail-label {
            font-size: 13px;
            color: #777;
            font-weight: 500;
        }
        
        .detail-value {
            font-size: 14px;
            font-weight: 600;
            color: #333;
            text-align: right;
        }
        
        .barcode-container {
            text-align: center;
            padding: 15px 20px;
            background: #f9f9f9;
            margin-top: 10px;
        }
        
        .barcode-container img {
            height: 50px;
            margin-bottom: 5px;
        }
        
        .barcode-text {
            font-size: 12px;
            color: #666;
            letter-spacing: 1px;
        }
        
        .ticket-footer {
            background: #f5f5f5;
            padding: 15px 20px;
            text-align: center;
            font-size: 12px;
            color: #777;
        }
        
        .error-message {
            color: #d9534f;
            font-weight: bold;
            padding: 30px;
            text-align: center;
        }
        
        .ticket-corner {
            position: absolute;
            width: 30px;
            height: 30px;
            background: #f5f7fa;
            border-radius: 50%;
            top: 50%;
            transform: translateY(-50%);
        }
        
        .ticket-corner.left {
            left: -15px;
        }
        
        .ticket-corner.right {
            right: -15px;
        }
        
        .watermark {
            position: absolute;
            opacity: 0.05;
            font-size: 80px;
            font-weight: bold;
            color: #6e48aa;
            transform: rotate(-30deg);
            top: 30%;
            left: 10%;
            pointer-events: none;
        }
    </style>";

    // Ticket content
    $ticketContent = "<div class='ticket-container'>";

    if ($error) {
        $ticketContent .= "<div class='error-message'>$error</div>";
    } else {
        $ticketContent .= "<div class='watermark'>CINEMA</div>";
        $ticketContent .= "<div class='ticket-header'>";
        $ticketContent .= "<h2>MOVIE TICKET</h2>";
        $ticketContent .= "<p>Admit One</p>";
        $ticketContent .= "</div>";
        
        $ticketContent .= "<img src='https://image.tmdb.org/t/p/w1280/7RyHsO4yDXtBv1zUU3mTpHeQ0d5.jpg' alt='Movie Banner' class='ticket-image'>";
        
        $ticketContent .= "<div class='ticket-details'>";
        $ticketContent .= "<div class='detail-row'>";
        $ticketContent .= "<span class='detail-label'>Movie</span>";
        $ticketContent .= "<span class='detail-value'>$movieTitle</span>";
        $ticketContent .= "</div>";
        
        $ticketContent .= "<div class='detail-row'>";
        $ticketContent .= "<span class='detail-label'>Date & Time</span>";
        $ticketContent .= "<span class='detail-value'>$showtime</span>";
        $ticketContent .= "</div>";
        
        $ticketContent .= "<div class='detail-row'>";
        $ticketContent .= "<span class='detail-label'>Theater</span>";
        $ticketContent .= "<span class='detail-value'>$theater</span>";
        $ticketContent .= "</div>";
        
        $ticketContent .= "<div class='detail-row'>";
        $ticketContent .= "<span class='detail-label'>Seats</span>";
        $ticketContent .= "<span class='detail-value'>$seats</span>";
        $ticketContent .= "</div>";
        
        $ticketContent .= "<div class='detail-row'>";
        $ticketContent .= "<span class='detail-label'>Duration</span>";
        $ticketContent .= "<span class='detail-value'>$duration</span>";
        $ticketContent .= "</div>";
        
        $ticketContent .= "<div class='detail-row'>";
        $ticketContent .= "<span class='detail-label'>Payment ID</span>";
        $ticketContent .= "<span class='detail-value'>" . substr($payment_id, 0, 8) . "...</span>";
        $ticketContent .= "</div>";
        
        $ticketContent .= "<div class='detail-row'>";
        $ticketContent .= "<span class='detail-label'>Amount Paid</span>";
        $ticketContent .= "<span class='detail-value'>₹$price</span>";
        $ticketContent .= "</div>";
        $ticketContent .= "</div>";
        
        $ticketContent .= "<div class='barcode-container'>";
        $ticketContent .= "<img src='$barcode' alt='Barcode'>";
        $ticketContent .= "<div class='barcode-text'>$unique_id</div>";
        $ticketContent .= "</div>";
        
        $ticketContent .= "<div class='ticket-footer'>";
        $ticketContent .= "<p>Please arrive at least 30 minutes before showtime</p>";
        $ticketContent .= "<p>© 2023 CineMagic Theaters. All Rights Reserved.</p>";
        $ticketContent .= "</div>";
        
        $ticketContent .= "<div class='ticket-corner left'></div>";
        $ticketContent .= "<div class='ticket-corner right'></div>";
    }

    $ticketContent .= "</div>";

    return $ticketStyle . $ticketContent;
}

// Check if payment_id, price, and unique_id are received
if (isset($_GET['payment_id']) && isset($_GET['price']) && isset($_GET['unique_id'])) {
    $payment_id = $_GET['payment_id'];
    $price = $_GET['price'];
    $unique_id = $_GET['unique_id'];

    // Save data to payments_details table
    $stmt = $conn->prepare("INSERT INTO payments_details (payment_id, price, unique_id) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $payment_id, $price, $unique_id);

    if ($stmt->execute()) {
        echo generateMovieTicket($payment_id, $price, $unique_id);
    } else {
        echo generateMovieTicket(null, null, null, "❌ Error storing payment details: " . $stmt->error);
    }

    $stmt->close();
    $conn->close();
} else {
    echo generateMovieTicket(null, null, null, "❌ No payment details received.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movie Ticket</title>
</head>
<body>
    
</body>
</html>