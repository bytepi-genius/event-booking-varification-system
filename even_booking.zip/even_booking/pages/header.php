<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Default logo path if no custom logo is uploaded
$default_logo = "../images/logo/default_logo.png";

// Check if custom logo is set in session or database
if (isset($_SESSION['logo']) && !empty($_SESSION['logo'])) {
    $logo_path = "../" . $_SESSION['logo']; // Use uploaded logo
} else {
    $logo_path = $default_logo; // Use default logo
}

// Default avatar if no profile pic uploaded
$default_avatar = "../images/profiles/man.png";

// Check if user avatar is set
$user_avatar = isset($_SESSION['avatar']) && !empty($_SESSION['avatar'])
    ? "../" . $_SESSION['avatar']
    : $default_avatar;
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Booking System</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css" />
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .navbar {
            background-color:rgb(0, 0, 0);
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }
        .navbar-logo img {
            height: 50px;
            cursor: pointer;
        }
        .navbar .right a {
            color: white;
            text-decoration: none;
            margin-left: 15px;
            font-size: 18px;
            transition: color 0.3s;
        }
        .navbar .right a:hover {
            color: #ff4d4d;
        }
        .user-profile {
            display: flex;
            align-items: center;
            cursor: pointer;
            position: relative;
        }
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 2px solid #fff;
            margin-left: 10px;
        }
        .dropdown-menu {
            position: absolute;
            right: 0;
            top: 50px;
            background-color: #fff;
            box-shadow: 0 5px 10px rgba(0,0,0,0.2);
            border-radius: 5px;
            overflow: hidden;
            display: none;
            z-index: 10;
        }
        .dropdown-menu a {
            padding: 10px 15px;
            display: block;
            color: #333;
            text-decoration: none;
        }
        .dropdown-menu a:hover {
            background-color: #f4f4f4;
        }
        .btn-logout {
            background-color: #ff4d4d;
            color: white;
            padding: 5px 12px;
            border: none;
            border-radius: 5px;
            margin-left: 15px;
            cursor: pointer;
        }
        .btn-logout:hover {
            background-color: #e33e3e;
        }

        .logo-upload {
    margin: 20px auto;
    text-align: center;
}
.logo-upload input[type="file"] {
    margin-top: 10px;
}
.navbar-logo img {
        height: 100px; /* Adjust height as needed */
        width: auto; /* Auto width to maintain aspect ratio */
        cursor: pointer;
    }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<div class="navbar">
    <!-- Logo Section -->
    <div class="navbar-logo">
        <a href="dashboard.php">
            <img src="../images/logo.png" alt="Movie Booking Logo">
        </a>
    </div>

<script>
    // Toggle Dropdown Menu
    function toggleDropdown() {
        var dropdown = document.getElementById("dropdownMenu");
        dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
    }

    // Hide dropdown if clicked outside
    window.onclick = function (event) {
        if (!event.target.matches('.user-avatar')) {
            var dropdown = document.getElementById("dropdownMenu");
            if (dropdown.style.display === "block") {
                dropdown.style.display = "none";
            }
        }
    }
</script>

</body>
</html>