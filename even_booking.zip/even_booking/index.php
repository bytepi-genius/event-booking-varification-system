
<!DOCTYPE html>
<html>

<head>
    <title>Movie Ticket Booking System</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #0b0c10;
        }

        .container {
            text-align: center;
            margin-top: 20px;
        }

        /* Navbar Styles */
        .navbar {
            background-color: #1f2833;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar h2 {
            margin: 0;
            color: #66fcf1;
            font-size: 24px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            margin-left: 15px;
        }

        .navbar a:hover {
            text-decoration: underline;
        }

        /* Banner Section */
        .banner-container {
            position: relative;
            width: 100%;
            height: 500px;
            overflow: hidden;
        }

        .banner-slide {
            display: none;
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .banner-active {
            display: block;
            animation: fadeIn 1.5s ease-in-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0.5;
            }

            to {
                opacity: 1;
            }
        }

        /* Overlay Text */
        .banner-text {
            position: absolute;
            bottom: 50px;
            left: 50%;
            transform: translateX(-50%);
            color: white;
            font-size: 28px;
            background: rgba(0, 0, 0, 0.7);
            padding: 10px 20px;
            border-radius: 10px;
        }

        /* Buttons Section */
        .cta-section {
            margin-top: 30px;
        }

        .cta-btn {
            background-color: #45a29e;
            padding: 10px 20px;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin: 10px;
        }

        .cta-btn:hover {
            background-color: #66fcf1;
        }

        /* Footer Section */
        .footer {
            background-color: #1f2833;
            padding: 10px 0;
            text-align: center;
            color: #66fcf1;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

  

        
    </style>
</head>

<body>

    <!-- Navbar -->
    <div class="navbar">
        <h2>Create Studio</h2>
        <div>
            <?php if (isset($_SESSION['user'])) : ?>
                <span style="color: #66fcf1;">Welcome, <strong><?php echo $_SESSION['user']; ?></strong>!</span>
                <a href="pages/dashboard.php" class="cta-btn">Go to Dashboard</a>
                <a href="php/logout.php" class="cta-btn">Logout</a>
            <?php else : ?>
                <a href="php/login.php" class="cta-btn">Login</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="banner-container">
    <!-- Video Slide -->
    <video class="banner-slide" autoplay muted loop id="video-slide">
        <source src="images/vd.mp4" type="video/mp4">
        Your browser does not support the video tag.
    </video>

    <!-- Image Slides (Hidden Initially) -->
    <div class="slideshow-container">
        <img src="images/logo.png" class="banner-slide" alt="Movie Banner 1">
        <img src="images/Red And Black Horror Movie Poster (2).png" class="banner-slide" alt="Movie Banner 2">
        <img src="images/download (1).jpeg" class="banner-slide" alt="Movie Banner 3">
    </div>

    <!-- Banner Text -->
    <div class="banner-text">
        🎥 Get Your Tickets Now & Enjoy the Best Movie Experience! 🍿
    </div>
</div>


    <!-- Call to Action Section -->
    <div class="cta-section">
        <a href="php/login.php" class="cta-btn">Book Tickets</a>
        <a href="php/register.php" class="cta-btn">Join Now</a>
    </div>

    <!-- Footer Section -->
    <div class="footer">
        <p>© 2025 Movie Booking System. All Rights Reserved.</p>
    </div>

    <!-- JavaScript for Banner Slide Show -->
    <script>
    let currentIndex = 0;
    const slides = document.querySelectorAll('.banner-slide');
    const videoSlide = document.getElementById('video-slide');

    function showSlides() {
        slides.forEach((slide, index) => {
            slide.style.display = 'none';
        });

        if (currentIndex === 0) {
            videoSlide.style.display = 'block';
            videoSlide.play();

            // Wait for video duration before changing to next slide
            videoSlide.onended = function () {
                currentIndex++;
                showSlides();
            };
        } else {
            slides[currentIndex].style.display = 'block';
            currentIndex++;
        }

        if (currentIndex >= slides.length) {
            currentIndex = 0;
        }
    }

    showSlides(); // Show initial slide

    // Change image every 3 seconds (only after video)
    setInterval(function () {
        if (currentIndex !== 0) {
            showSlides();
        }
    }, 2000);
</script>

</body>

</html>
